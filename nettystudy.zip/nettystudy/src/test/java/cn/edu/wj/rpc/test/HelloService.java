package cn.edu.wj.rpc.test;

public interface HelloService {

	public String sayHi(String msg);
	
}
