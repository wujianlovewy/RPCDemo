package cn.edu.wj.dubbo.common.serialize.model;

public enum PersonStatus {
	ENABLED,
    DISABLED
}
