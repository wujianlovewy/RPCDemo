package test.cn.edu.wj.demo.mango.ext;

public class ExtServiceImpl implements ExtService {

	public String testExt(){
		System.out.println("testExt");
		return "testExt";
	}
}
