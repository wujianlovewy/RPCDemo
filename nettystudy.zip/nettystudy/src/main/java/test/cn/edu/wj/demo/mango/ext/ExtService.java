package test.cn.edu.wj.demo.mango.ext;

import cn.edu.wj.rpc.mango.ext.SPI;

@SPI
public interface ExtService {
	
	public String testExt();

}
