package cn.edu.wj.netty.day2;

public class ServerTest {

	public static void main(String[] args) {
		new DemoServer(9999).start(); 
	}
	
}
