package cn.edu.wj.rpc.demo;

public class Constant {

	static int ZK_SESSION_TIMEOUT = 6000;

    static String ZK_REGISTRY_PATH = "/registry";
    static String ZK_DATA_PATH = ZK_REGISTRY_PATH+"/address";
	
}
