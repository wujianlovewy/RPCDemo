package cn.edu.wj.rpc.dubbo.netty;

public interface Server {

}
